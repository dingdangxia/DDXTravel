var a = /./u;
var b = /[\0-\u{10FFFF}]/u;
