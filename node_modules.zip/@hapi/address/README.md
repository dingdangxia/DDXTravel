<a href="http://hapijs.com"><img src="https://raw.githubusercontent.com/hapijs/assets/master/images/family.png" width="180px" align="right" /></a>

# @hapi/address

Validate email address and domain

[![Build Status](https://secure.travis-ci.org/hapijs/address.svg)](http://travis-ci.org/hapijs/address)
